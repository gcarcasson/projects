import detectenglish
from transposition_sol import TransCipher

def main():
    secretmessage1 = """"ccdnye ee.iCru.g ,
yy"noer ss   o-smda
 la an tpit aon rd
eube rwd e  itl, e, T i ney    bopm r aHiirgoa sfnunniewgA admcalteilas arclhrnbrtsneciefaee,t duarutr  ubirn litiapebatt o nciilt.hbnE"""

    secretmessage2 = """Cr sosoemd tiohus oohs au e oosr reHnvaawggcmtng eaaaagecgrehobrlrl sgrvrnkei, deayaia ecea e.t dern pkdt h tyr ete  sthevhy fuo 
 hcytphylaeoaulubYyerohoe!yn unnaryoonyuas 
 cR d ts uu p tibTseSt hiedrrwth teoedAoeaole  aiasigdc   xcnfclolnvuoiauecdpks oawkgebnnyrnioei!adsn   s n,ecp rn  it siwtci drhyigYfn sotriiny yeom!oogtem itpgouprueur aceutuh ust.rn mtsrostteorii
 thihkenieirf noIoaadi tennos dgn wtvasi  g.n ca  enieb smt 
 artasn o lm ehtRarya ucrnpeetsrhenep mcoe!"""
    
    print(hack(secretmessage2))
    
def hack(text):
    print('Hacking...')

    # Loop through every possible key
    for key in range(1,len(text)):
        print(f"Attempting key {key}")
        # decrypt
        message = TransCipher(text,key,False)
        message.decrypt()

        # test if English
        if detectenglish.isitenglish(message.plaintext):
            # Show a bit to the user and ask them to confirm
            print(message.plaintext[:100])
            response = input('Enter C to confirm or any other key to continue: ')
            if response.upper() == 'C':
                return message.plaintext
    return None

if __name__ == '__main__':
    main()