import os, sys, time
from transposition_sol import TransCipher

def main():
    input_file = 'woolf_encrypted.txt'
    output_file = 'woolf2.txt'
    key = 724
    mode = 'Decrypt'

    # check python can actually find the file
    if not os.path.exists(input_file):
        print(f"The file {input_file} does not exist")
        sys.exit()

    # read file
    file_object = open(input_file)
    content = file_object.read()
    file_object.close()

    print(f"{mode}ing {input_file}...")

    start_time = time.time()

    # translate
    if mode == 'Encrypt': 
        print(f"Encrypting {input_file}")
        original = TransCipher(content,key)
        translated = original.encrypt()
    else: 
        print(f"Decrypting {input_file}")
        original = TransCipher(content,key,False)
        translated = original.decrypt()

    total_time = round(time.time() - start_time, 2)
    print(f"{mode}ion time: {total_time} seconds")

    # write to output file
    output_object = open(output_file, 'w') # write mode
    output_object.write(translated)
    output_object.close()

    print("Done!")

if __name__ == '__main__':
    main()