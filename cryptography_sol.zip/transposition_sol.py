class TransCipher:
    def __init__(self, message, key, isplaintext = True):
        self.key = key
        if isplaintext:
            self.plaintext = message
            self.encrypted = None
        else: 
            self.plaintext = None
            self.encrypted = message

    def encrypt(self):
        # create 8 columns with empty strings
        ciphertext = ['']*self.key

        # loop through each column
        for col in range(self.key):
            currentindex = col
            while currentindex < len(self.plaintext):
                # place character at end of current column
                ciphertext[col] += self.plaintext[currentindex]
                # move currentindex
                currentindex += self.key
        
        # convert to one string
        self.encrypted = ''.join(ciphertext)
        return self.encrypted

    def decrypt(self):
        # calculate number of columns (number of rows = key)
        numcols = len(self.encrypted)//self.key
        if len(self.encrypted) % self.key > 0:
            numcols += 1
        
        # calculate number of boxes to shade
        shaded = numcols*self.key - len(self.encrypted)

        # create grid
        plaintext = [''] * numcols

        col = 0
        row = 0
        for char in self.encrypted:
            # write the next character in the message
            plaintext[col] += char
            # move to the right
            col += 1

            # check if we need to move to the next row
            endofrow = col == numcols
            # check if this box is shaded
            shadedbox = col == numcols-1 and row >= self.key-shaded

            # if either of the above conditions are true, move to the first column and next row
            if endofrow or shadedbox:
                col = 0
                row += 1

        # combine into one message
        self.plaintext = ''.join(plaintext)
        return self.plaintext

def main():
    test = TransCipher("Meet at the docks at midnight.", 2)
    test.encrypt()
    print(test.encrypted + "|")
    test.decrypt()
    print(test.plaintext)

    secret = TransCipher("Cusdes gol er wnayc togtorsorriuye kaorpebitn tmen", 7, False)
    secret.decrypt()
    print(secret.plaintext)

if __name__ == '__main__':
    main()
