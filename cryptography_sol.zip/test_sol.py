import random,sys
from transposition_sol import TransCipher

def main():
    random.seed(42) 

    numtests = 20
    possiblechars = 'abcdefghijklmnopqrstuvwxyz'

    # run tests
    for i in range(numtests):
        # generate random text
        length = random.randint(4,50)
        text = possiblechars * length

        # shuffle text
        text = list(text)
        random.shuffle(text)
        text = ''.join(text)

        print(f"Test {i+1}: {text[:25]}...")

        # test all possible keys
        for key in range(1,len(text)//2):
            message = TransCipher(text,key)
            # encrypt and decrypt message
            message.encrypt()
            message.decrypt()

            # check we end up with the original text
            if text != message.plaintext:
                # error message
                print(f"Error with key {key} and text #{i+1}")
                print(f"Ciphertext: {message.encrypted}")
                print(f"Decrypted as {message.plaintext}")
                sys.exit()
        
        print("passed")


if __name__ == '__main__':
    main()