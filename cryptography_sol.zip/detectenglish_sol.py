alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + " \t\n"

# create dictionary of dictionary words
def create_dict(filename):
    dictionary_file = open(filename)
    english_words = {}
    for word in dictionary_file.read().split('\n'):
        english_words[word] = None
    dictionary_file.close()

    return english_words

english_words = create_dict('dictionary.txt')

# remove extra symbols from message
def remove_symbols(message):
    newmessage = []
    for char in message:
        if char in alphabet:
            newmessage.append(char)
    return ''.join(newmessage)

def count_words(message):
    # turn everything uppercase and remove symbols
    message = message.upper()
    message = remove_symbols(message)

    # split message into 'words'
    blocks = message.split()

    # count how many of the blocks are actually words
    count = 0
    for word in blocks:
        if word in english_words:
            count += 1

    return count / len(blocks)


def isitenglish(message,wordpercent=40,letterpercent=85):
    # word percent is how many words are in the dictionary
    # letter percent is how many characters are in bigalphabet
    mywordpercent = count_words(message) * 100
    myletterpercent = len(remove_symbols(message)) / len(message) * 100
    enoughwords = mywordpercent >= wordpercent
    enoughletters = myletterpercent >= letterpercent
    return enoughwords and enoughletters
