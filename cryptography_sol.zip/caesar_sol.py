import random

alphabet = "abcdefghijklmnopqrstuvwxyz"

def encrypt(message, key):
    translated = ''
    for char in message:
        if char in alphabet:
            char_index = alphabet.find(char)
            translated_index = (char_index + key) % len(alphabet)
            translated += alphabet[translated_index]
        else: 
            translated += char
    return translated

print(encrypt('Drop the $$$ at 2408 Elms ST.',7))

# what about symbols not in the alphabet?
# what about upper/lowercase?
# can we reuse code for encrypting and decrypting?

symbols = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!?@#$%^&*()' "


def caesar(message,key,mode): #encrypting = 1, decrypting = -1
    translated = ''
    #message = message.lower()
    for char in message:
        if char in symbols:
            char_index = symbols.find(char)
            translated_index = (char_index + mode*key) % len(symbols)
            translated += symbols[translated_index]
        else:
            translated += char
    return translated

test = "Wow! This works well, don't you think so?"
key = 3
test = (caesar(test,key,1))
print(test)
print(caesar(test,key,-1))

secretmessage = "Nice job! Next we'll?"
key = random.randrange(len(symbols))
secretmessage = caesar(secretmessage,key,1)
print(secretmessage)
print()

def bruteforce(message):
    for key in range(len(symbols)):
        attempt = caesar(message,key,-1)
        print(f"Key {key} : {attempt}")
    return None

bruteforce(secretmessage)